package kelas;

import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Navigator {

    private static Stage mainStage;

    public static void setStage(Stage stage) {
        mainStage = stage;
    }

    public static void bukaDaftar() {
        bukaHalaman("/kelas/daftar.fxml");
    }

    public static void bukaForm() {
        bukaHalaman("/kelas/form.fxml");
    }

    public static void bukaDetail() {
        bukaHalaman("/kelas/detail.fxml");
    }

    private static void bukaHalaman(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(Navigator.class.getResource(fxmlPath));
            Parent root = loader.load();
            
            if (mainStage != null) {
                Scene scene = new Scene(root, 850, 600);
                
                URL cssUrl = Navigator.class.getResource("/kelas/styles/app.css");
                if (cssUrl != null) {
                    scene.getStylesheets().add(cssUrl.toExternalForm());
                } else {
                    System.out.println("Warning: File app.css tidak ditemukan di /kelas/styles/app.css");
                }

                mainStage.setScene(scene);
                mainStage.setMinWidth(800);
                mainStage.setMinHeight(550);
                mainStage.show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}