package kelas.data;

import java.util.ArrayList;
import java.util.List;
import kelas.model.Produk;

public class DataProduk {
    private static final List<Produk> daftarProduk = new ArrayList<>();
    private static Produk produkDipilih;

    public static void tambahProduk(Produk produk) {
        daftarProduk.add(produk);
    }

    public static List<Produk> getDaftarProduk() {
        return daftarProduk;
    }

    public static void hapusProduk(Produk produk) {
        daftarProduk.remove(produk);
    }

    public static Produk getProdukDipilih() {
        return produkDipilih;
    }

    public static void setProdukDipilih(Produk produk) {
        produkDipilih = produk;
    }
}