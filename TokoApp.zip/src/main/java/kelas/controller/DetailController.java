package kelas.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import kelas.Navigator;
import kelas.data.DataProduk;
import kelas.model.Produk;

public class DetailController implements Initializable {

    @FXML
    private Label kodeLabel;
    @FXML
    private Label namaLabel;
    @FXML
    private Label kategoriLabel;
    @FXML
    private Label hargaLabel;
    @FXML
    private ImageView gambarView; // Menggunakan gambarView

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Produk p = DataProduk.getProdukDipilih();
        if (p != null) {
            kodeLabel.setText(p.getId());
            namaLabel.setText(p.getNama());
            kategoriLabel.setText(p.getKategori());
            hargaLabel.setText(String.format("%,.0f", p.getHarga()));

            if (p.getFoto() != null && !p.getFoto().isEmpty()) {
                try {
                    gambarView.setImage(new Image(p.getFoto()));
                } catch (Exception e) {
                    System.out.println("Gagal memuat foto produk!");
                }
            }
        }
    }

    @FXML
    private void bukaDaftar(ActionEvent event) {
        Navigator.bukaDaftar();
    }

    @FXML
    private void tambah(ActionEvent event) {
        Navigator.bukaForm();
    }
}