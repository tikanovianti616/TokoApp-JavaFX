package kelas.controller;

import java.net.URL;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import kelas.Navigator;
import kelas.data.DataProduk;
import kelas.model.Produk;

public class DaftarController implements Initializable {

    @FXML
    private TextField cariField;
    @FXML
    private ComboBox<String> kategoriBox; 
    @FXML
    private TableView<Produk> produkTable;
    @FXML
    private TableColumn<Produk, String> kodeCol; 
    @FXML
    private TableColumn<Produk, String> namaCol;
    @FXML
    private TableColumn<Produk, String> kategoriCol;
    @FXML
    private TableColumn<Produk, String> hargaCol;

    private ObservableList<Produk> masterData = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        kodeCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        namaCol.setCellValueFactory(new PropertyValueFactory<>("nama"));
        kategoriCol.setCellValueFactory(new PropertyValueFactory<>("kategori"));
        
        hargaCol.setCellValueFactory(cellData -> {
            double harga = cellData.getValue().getHarga();
            NumberFormat formatter = NumberFormat.getInstance(new Locale("id", "ID"));
            return new SimpleStringProperty(formatter.format(harga));
        });

        if (kategoriBox != null) {
            kategoriBox.setItems(FXCollections.observableArrayList(
                "Semua Kategori", "Makanan", "Minuman", "Pakaian", "Elektronik", "Lainnya"
            ));
            kategoriBox.setValue("Pilih Kategori");
        }

        tampilkanSemuaData();
    }

    private void tampilkanSemuaData() {
        masterData.setAll(DataProduk.getDaftarProduk());
        produkTable.setItems(masterData);
    }

    @FXML
    private void cari(ActionEvent event) {
        String keyword = cariField.getText().toLowerCase().trim();
        String katFilter = (kategoriBox != null && kategoriBox.getValue() != null) 
                           ? kategoriBox.getValue() : "Pilih Kategori";

        ObservableList<Produk> hasilCari = FXCollections.observableArrayList();
        
        for (Produk p : DataProduk.getDaftarProduk()) {
            boolean matchKeyword = keyword.isEmpty() || 
                                   p.getId().toLowerCase().contains(keyword) || 
                                   p.getNama().toLowerCase().contains(keyword);
            
            boolean matchKategori = katFilter.equals("Pilih Kategori") || 
                                    p.getKategori().equalsIgnoreCase(katFilter);

            if (matchKeyword && matchKategori) {
                hasilCari.add(p);
            }
        }
        produkTable.setItems(hasilCari);
    }

    @FXML
    private void reset(ActionEvent event) {
        cariField.clear();
        if (kategoriBox != null) {
            kategoriBox.setValue("Pilih Kategori");
        }
        tampilkanSemuaData();
    }

    @FXML
    private void tambah(ActionEvent event) {
        Navigator.bukaForm();
    }

    @FXML
    private void lihatDetail(ActionEvent event) {
        Produk terpilih = produkTable.getSelectionModel().getSelectedItem();
        if (terpilih != null) {
            DataProduk.setProdukDipilih(terpilih);
            Navigator.bukaDetail();
        } else {
            System.out.println("Pilih produk terlebih dahulu di tabel!");
        }
    }

    @FXML
    private void hapus(ActionEvent event) {
        Produk terpilih = produkTable.getSelectionModel().getSelectedItem();
        if (terpilih != null) {
            DataProduk.hapusProduk(terpilih);
            tampilkanSemuaData();
        } else {
            System.out.println("Pilih produk yang ingin dihapus!");
        }
    }
}