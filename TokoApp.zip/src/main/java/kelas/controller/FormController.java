package kelas.controller;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import kelas.Navigator;
import kelas.data.DataProduk;
import kelas.model.Produk;

public class FormController implements Initializable {

    @FXML
    private TextField namaField;
    @FXML
    private ComboBox<String> kategoriCombo;
    @FXML
    private TextField hargaField;
    @FXML
    private ImageView gambarview; 

    private String pathFotoTerpilih = "";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if (kategoriCombo != null) {
            kategoriCombo.setItems(FXCollections.observableArrayList(
                "Makanan", "Minuman", "Pakaian", "Elektronik", "Lainnya"
            ));
        }
    }

    @FXML
    private void simpan(ActionEvent event) {
        String nama = namaField.getText();
        String kategori = kategoriCombo.getValue();
        String inputHargaRaw = hargaField.getText();

        if (nama == null || nama.isEmpty() || kategori == null || inputHargaRaw == null || inputHargaRaw.isEmpty()) {
            System.out.println("Semua field wajib diisi!");
            return;
        }

        try {
            String hargaClean = inputHargaRaw.replaceAll("[^0-9]", "");
            double harga = Double.parseDouble(hargaClean);

            int nextId = DataProduk.getDaftarProduk().size() + 1;
            String id = "PRD-" + nextId;

            Produk produkBaru = new Produk(id, nama, kategori, harga, pathFotoTerpilih);
            DataProduk.tambahProduk(produkBaru);

            Navigator.bukaDaftar();
        } catch (NumberFormatException e) {
            System.out.println("Input harga tidak valid!");
        }
    }

    @FXML
    private void pilihGambar(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Pilih Foto Produk");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        
        javafx.stage.Window stage = ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        File fileTerpilih = fileChooser.showOpenDialog(stage);
        
        if (fileTerpilih != null) {
            pathFotoTerpilih = fileTerpilih.toURI().toString();
            
            if (gambarview != null) {
                gambarview.setImage(new Image(pathFotoTerpilih));
            } else {
                System.out.println("ERROR: gambarview masih null! Cek fx:id di Scene Builder.");
            }
        }
    }

    @FXML
    private void bukaDaftar(ActionEvent event) {
        Navigator.bukaDaftar();
    }
}