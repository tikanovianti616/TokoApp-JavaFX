package kelas.model;

public class Produk {
    private String id;
    private String nama;
    private String kategori;
    private double harga;
    private String foto; 

    public Produk(String id, String nama, String kategori, double harga, String foto) {
        this.id = id;
        this.nama = nama;
        this.kategori = kategori;
        this.harga = harga;
        this.foto = foto;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getKategori() { return kategori; }
    public void setKategori(String kategori) { this.kategori = kategori; }

    public double getHarga() { return harga; }
    public void setHarga(double harga) { this.harga = harga; }

    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }
}